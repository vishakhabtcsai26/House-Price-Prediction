# House Price Prediction using Machine Learning

This project predicts house prices based on features like number of bedrooms, bathrooms, and house size (sqft). The project uses Python, pandas, and scikit-learn for building a machine learning model.

## Features
- Data preprocessing and cleaning
- Train-test split
- Model training using Random Forest Regressor
- Evaluation using Mean Squared Error (MSE) and R² Score
- Predict price for new houses

## Dataset
The dataset (`house_data.csv`) contains sample data with the following columns:
- Bedrooms
- Bathrooms
- Size(sqft)
- Price

## How to Run
1. Install dependencies:
```
pip install pandas scikit-learn
```
2. Run the Python script:
```
python house_price_prediction.py
```
3. Check predicted prices and model evaluation metrics in the console.
